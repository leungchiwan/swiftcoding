/*
 * Version: 1.0
 * Author: Ivan Fong
 * Date: 21 Nov 2022
 * Comment: This is a quick a implementation Speed Tab App
 */

import SwiftUI

struct ContentView: View {
    @State var leftButtonText = "0"
    @State var rightButtonText = "0"
    
    var body: some View {
        VStack {
            Spacer()
            HStack{
                Spacer()
                Text("Speed Tab App")
                    .font(.system(size: 70, weight: Font.Weight.bold))
                Spacer()
            }
            Spacer()
            HStack{
                Spacer()
                Text(leftButtonText)
                    .bold()
                    .font(.system(size: 50, weight: Font.Weight.bold))
                Spacer()
                Text(rightButtonText)
                    .bold()
                    .font(.system(size: 50, weight: Font.Weight.bold))
                Spacer()
                
            }
            Spacer()
            
            HStack{
                Spacer()
                
                Button("Tap Me"){
                    leftButtonText =  String(NumberFormatter().number(from: leftButtonText) as! Int + 1)
                }
                .padding()
                .font(.system(size: 30, weight: Font.Weight.bold))
                .foregroundColor(Color.white)
                .background(RoundedRectangle(cornerRadius: 8).fill(Color.blue))
                .buttonStyle(PlainButtonStyle())
            
                
                Spacer()
                
                Button("Tap Me") {
                    rightButtonText =  String(NumberFormatter().number(from: rightButtonText) as! Int + 1)
                }
                .padding()
                .font(.system(size: 30, weight: .bold, design: .default))
                .foregroundColor(Color.white)
                .background(RoundedRectangle(cornerRadius: 8).fill(Color.blue))
                .buttonStyle(PlainButtonStyle())
                
                Spacer()
                
            }
            Spacer()
            Button("Reset"){
                leftButtonText = "0"
                rightButtonText = "0"
            }
            .padding()
            .font(.system(size: 30, weight: .bold, design: .default))
            .foregroundColor(Color.white)
            .background(RoundedRectangle(cornerRadius: 8).fill(Color.red))
            .buttonStyle(PlainButtonStyle())
            
        }
    }
}
